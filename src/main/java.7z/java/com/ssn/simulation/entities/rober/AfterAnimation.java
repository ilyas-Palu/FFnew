package com.ssn.simulation.entities.rober;

public enum AfterAnimation {
    Delete,
    OnOutputOnInput
}
