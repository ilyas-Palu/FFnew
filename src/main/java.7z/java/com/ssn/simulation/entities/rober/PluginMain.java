package com.ssn.simulation.entities.rober;

import com.ssn.simulation.plugin.Plugin;
import com.ssn.simulation.builders.EntityBuilder;
import com.ssn.simulation.core.Entity;
import com.ssn.simulation.editor.EntityConverter;
import com.ssn.simulation.functions.UserFunction;
import java.util.ArrayList;
import java.util.List;

public class PluginMain implements Plugin {
    public String getId() {
        return "ro-ber";
      }
      
      public List<Class<? extends Entity>> registerEntities() {
        List<Class<? extends Entity>> list = new ArrayList<>();
        list.add(RoBerController.class);
        list.add(RoBerConveyor.class);
        return list;
      }
      
      public List<UserFunction> registerUserFunctions() {
        return null;
      }
      
      public List<EntityBuilder> registerEntityBuilders() {
        return null;
      }
      
      public List<EntityConverter> registerEntityConverters() {
        return null;
      }
}