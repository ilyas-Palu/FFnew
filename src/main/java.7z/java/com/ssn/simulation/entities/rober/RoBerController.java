package com.ssn.simulation.entities.rober;

import java.awt.Color;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.ssi.wasoc.WaSoc;
import com.ssi.wasoc.api.WaSocConnectionRegistry;
import com.ssi.wasoc.api.WaSocTelegramHandler;
import com.ssi.wasoc.api.cfg.WaSocConnectionCfg;
import com.ssi.wasoc.api.executor.WaSocThreadPoolExecutorFactory;
import com.ssi.wasoc.api.telegram.InboundTelegram;
import com.ssi.wasoc.api.telegram.OutboundTelegram;
import com.ssn.simulation.core.Entity;
import com.ssn.simulation.core.Item;
import com.ssn.simulation.entities.AbstractConveyor;
import com.ssn.simulation.entities.rober.communication.ASCIIConnectionCfg;
import com.ssn.simulation.entities.rober.communication.ByteHandler;
import com.ssn.simulation.entities.rober.communication.ByteWriteException;
import com.ssn.simulation.entities.rober.communication.ProtocolAdapterCfg;
import com.ssn.simulation.entities.rober.communication.TelegramHeaderFields;
import com.ssn.simulation.entities.rober.communication.telegramtypes.APNOAnnouncementPointNotification;
import com.ssn.simulation.entities.rober.communication.telegramtypes.CANC;
import com.ssn.simulation.entities.rober.communication.telegramtypes.CDOR;
import com.ssn.simulation.entities.rober.communication.telegramtypes.CORDConsolidationOrder;
import com.ssn.simulation.entities.rober.communication.telegramtypes.DEPO;
import com.ssn.simulation.entities.rober.communication.telegramtypes.DORDDepalletizingOrder;
import com.ssn.simulation.entities.rober.communication.telegramtypes.OSTAOrderStatus;
import com.ssn.simulation.entities.rober.communication.telegramtypes.PORDPalletizingOrder;
import com.ssn.simulation.entities.rober.communication.telegramtypes.PUPO;
import com.ssn.simulation.entities.rober.communication.telegramtypes.RoBerTelegram;
import com.ssn.simulation.entities.rober.communication.telegramtypes.UnknownTelegram;
import com.ssn.simulation.entities.rober.orders.RoBerOrder;
import com.ssn.simulation.entities.rober.telegramHandlers.APNO;
import com.ssn.simulation.entities.rober.telegramHandlers.Order;
import com.ssn.simulation.entities.rober.telegramHandlers.TelegramHandler;
import com.ssn.simulation.entities.rober.telegramHandlers.TelegramHandlerCfg;
import com.ssn.simulation.properties.BooleanProperty;
import com.ssn.simulation.properties.DoubleProperty;
import com.ssn.simulation.properties.IntegerProperty;
import com.ssn.simulation.properties.ListProperty;
import com.ssn.simulation.properties.LongProperty;
import com.ssn.simulation.properties.PropertyTooltip;
import com.ssn.simulation.properties.StringProperty;

public class RoBerController extends Entity implements WaSocTelegramHandler {

    @IntegerProperty(category = "Connection")
    protected int port;

    @StringProperty(category = "Connection")
    protected String sender;

    @StringProperty(category = "Connection")
    protected String receiver;

    @StringProperty(category = "Connection")
    protected String resource;

    @IntegerProperty(category = "Connection")
    protected int telegramLength;

    @StringProperty(category = "Connection")
    protected String fillCharacter;

    @StringProperty(category = "Connection")
    protected String telegramTerminatorString;

    @IntegerProperty(category = "Connection")
    protected int maxSeqno;

    @LongProperty(category = "Connection")
    protected long waitForAckTimeout = 10000;

    @BooleanProperty(category = "Connection")
    protected boolean sendLifeTelegram;

    @LongProperty(category = "ro-ber")
    protected long processingTimePUPO = 5000;

    @LongProperty(category = "ro-ber")
    protected long processingTimeDEPO = 5000;

    @LongProperty(category = "ro-ber")
    protected long processingTimeCDOR = 5000;

    @StringProperty(category = "ro-ber")
    protected String palletCoverConveyor;

    @ListProperty(category = "ro-ber", clazz = ConveyorIdMapping.class)
    @PropertyTooltip("mapping of ro-ber conveyor IDs to antSim conveyor ID (not necessary if ID is equal)")
    protected List<ConveyorIdMapping> conveyorIdMapping;

    @DoubleProperty(category = "ro-ber")
    @PropertyTooltip("length of bins created during depalletizing")
    protected double binSizex = 0.6;

    @DoubleProperty(category = "ro-ber")
    @PropertyTooltip("widht of bins created during depalletizing")
    protected double binSizey = 0.4;

    @DoubleProperty(category = "ro-ber")
    @PropertyTooltip("height of bins created during depalletizing")
    protected double binSizez = 0.2;

    @JsonIgnore
    protected transient WaSocThreadPoolExecutorFactory executorFactory;
    @JsonIgnore
    protected transient WaSocConnectionRegistry connectionRegistry;

    @JsonIgnore
    protected Map<String, TelegramHandlerCfg> telegramHandlers;
    @JsonIgnore
    protected volatile int sndSeqno = 0;
    @JsonIgnore
    protected volatile int rcvSeqno = 0;
    @JsonIgnore
    protected ByteHandler byteHandler;
    @JsonIgnore
    protected RoBerOrder order;

    @Override
    public void onReset() {
        super.onReset();

        this.order = null;
        this.sndSeqno = 0;
        this.rcvSeqno = 0;

        for (var e : this.getEntitiesByClass(RoBerConveyor.class)) {
            e.setController(this);
        }

        this.checkConveyorIdMapping();
    }

    protected void checkConveyorIdMapping() {
        var iter = this.conveyorIdMapping.listIterator();
        while (iter.hasNext()) {
            var entry = iter.next();
            var entity = this.core.getEntityById(entry.getConveyorId());
            if (entity == null) {
                this.logError("no entity with ID " + id + " found which is configured in ro-ber mapping");
                iter.remove();
            } else if (!(entity instanceof AbstractConveyor)) {
                this.logError("entity with ID " + id + " which is configured in ro-ber mapping is not a conveyor");
                iter.remove();
            } else if (entity instanceof RoBerConveyor
                    && !((RoBerConveyor) entity).getRoberResource().equals(this.resource)) {
                this.logError("conveyor " + id + " has not ro-ber resource " + this.resource);
                iter.remove();
            } else if (entity instanceof RoBerConveyor) {
                ((RoBerConveyor) entity).setRoberId(entry.getRoberId());
            }
        }
    }

    public RoBerOrder getOrder() {
        return order;
    }

    public void setOrder(RoBerOrder order) {
        this.order = order;
    }

    public synchronized void connect() {
        this.core.logInfo(this, "open server on port " + this.port);
        try {
            this.byteHandler = new ByteHandler(this.fillCharacter.getBytes()[0], this.telegramLength,
                    this.telegramTerminatorString.getBytes());
            this.executorFactory = WaSoc.createDefaultExecutorFactory();
            this.connectionRegistry = WaSoc.createSocketConnectionRegistry(this.executorFactory);
            var cfg = this.createConnection();
            this.connectionRegistry.configureConnection(cfg, this);
            this.executorFactory.startAll();
        } catch (Exception e) {
            this.core.logError(this, "unable to connect: " + e.toString(), e);
        }
        this.core.logInfo(this, "ro-ber connected");
    }

    public synchronized void disconnect() {
        if (this.executorFactory == null) {
            return;
        }
        this.executorFactory.stopAll();
        this.executorFactory = null;
        this.connectionRegistry = null;
    }

    @Override
    public void onLoad() {
        this.telegramHandlers = new HashMap<String, TelegramHandlerCfg>();
        this.registerTelegramHandlers();
    }

    @Override
    public String getCategory() {
        return "ro-ber";
    }

    @Override
    public void onEnterRuntimeMode() {
        super.onEnterRuntimeMode();
        this.connect();
    }

    @Override
    public void onExitRuntimeMode() {
        super.onExitRuntimeMode();
        this.disconnect();
    }

    protected void registerTelegramHandlers() {
        this.registerTelegramHandler(APNOAnnouncementPointNotification.TELETYPE,
                APNOAnnouncementPointNotification.class, new APNO(this));

        // register order handlers
        var order = new Order(this);
        this.registerTelegramHandler(PORDPalletizingOrder.TELETYPE, PORDPalletizingOrder.class,
                (tele) -> order.handleStartOrderTelegram(tele));
        this.registerTelegramHandler(DORDDepalletizingOrder.TELETYPE, DORDDepalletizingOrder.class,
                (tele) -> order.handleStartOrderTelegram(tele));
        this.registerTelegramHandler(CORDConsolidationOrder.TELETYPE, CORDConsolidationOrder.class,
                (tele) -> order.handleStartOrderTelegram(tele));

        this.registerTelegramHandler(PUPO.TELETYPE, PUPO.class, (tele) -> order.handleOrderTelegram(tele));
        this.registerTelegramHandler(CDOR.TELETYPE, CDOR.class, (tele) -> order.handleOrderTelegram(tele));
        this.registerTelegramHandler(DEPO.TELETYPE, DEPO.class, (tele) -> order.handleOrderTelegram(tele));
    }

    public void sendOSTA(String source, String huident, String mfserror) {
        var osta = this.createTelegram(OSTAOrderStatus.class);
        osta.setSource(source);
        osta.setHuident(huident);
        osta.setMfserror(mfserror);
    }

    protected WaSocConnectionCfg createConnection() {
        var config = new ProtocolAdapterCfg();
        config.setWaitForAckTimeout(this.waitForAckTimeout);
        return new ASCIIConnectionCfg(this.sender, "0.0.0.0", this.port, true, this.byteHandler, config);
    }

    public void registerTelegramHandler(String teletype, Class<? extends RoBerTelegram> telegramClass,
            TelegramHandler handler) {
        this.telegramHandlers.put(teletype, new TelegramHandlerCfg(handler, telegramClass));
    }

    @Override
    public synchronized boolean handleTelegram(InboundTelegram inboundTelegram) {
        try {
            var header = this.byteHandler.read(inboundTelegram.getPayload(), TelegramHeaderFields.class);
            if (header.getSeqno() > 0 && header.getSeqno() == this.rcvSeqno) {
                this.core.logDebug(this,
                        "telegram with seqno " + header.getSeqno() + " already processed -> ignoring telegram");
                return true;
            }
            this.rcvSeqno = header.getSeqno();

            var handlerCfg = this.telegramHandlers.get(header.getTeletype());
            if (handlerCfg == null) {
                var telegram = this.createTelegram(UnknownTelegram.class);
                telegram.setHeader(header);
                this.core.logReceive(telegram);
                this.core.logError(this, "unknown telegram type " + header.getTeletype());
            } else {
                var telegram = this.createTelegram(handlerCfg.getTelegramClass());
                telegram.setHeader(header);
                this.byteHandler.read(inboundTelegram.getPayload(), telegram);
                this.core.logReceive(telegram);
                handlerCfg.getHandler().handleTelegram(telegram);
            }
        } catch (Exception e) {
            this.core.logError(this, e.getMessage());
        }
        return true;
    }

    public synchronized int getNextSeqno() {
        int seqno = this.sndSeqno;
        this.sndSeqno = this.sndSeqno == this.maxSeqno ? 1 : this.sndSeqno + 1;
        return seqno;
    }

    public void sendTelegram(RoBerTelegram telegram) {
        try {
            this.setTelegramHeaderFields(telegram);
            var connection = this.connectionRegistry.getConnection(this.sender);
            connection.sendTelegramAsync(new OutboundTelegram(telegramToBytes(telegram)));
            this.core.logSend(telegram);
        } catch (Exception e) {
            this.logError("failed to send " + telegram.getTelegramType() + " telegram: " + e.getMessage());
        }
    }

    public void setTelegramHeaderFields(RoBerTelegram telegram) {
        var header = telegram.getHeader();
        header.setSender(this.sender);
        header.setReceiver(receiver);
        header.setHandshake(TelegramHeaderFields.HANDSHAKEK_DATA_TEL);
        header.setTeletype(telegram.getTelegramType());
        header.setSeqno(this.getNextSeqno());
        header.setResource(this.resource);
    }

    public byte[] telegramToBytes(RoBerTelegram telegram) throws ByteWriteException {
        var bytes = this.byteHandler.createTelegram();
        this.byteHandler.write(telegram.getHeader(), bytes);
        this.byteHandler.write(telegram, bytes);
        return bytes;
    }

    public List<Entity> getEntities() {
        var entities = this.core.getEntitiesByController(this);
        if (entities.isEmpty()) {
            for (Entity entity : this.core.getEntities()) {
                if (entity instanceof RoBerConveyor) {
                    var conv = (RoBerConveyor) entity;
                    if (this.resource != null && this.resource.equals(conv.roberResource)) {
                        entities.add(entity);
                    }
                }
            }
        }
        return entities;
    }

    @SuppressWarnings("unchecked")
    public <T> List<T> getEntitiesByClass(Class<T> clazz) {
        var entities = new ArrayList<T>();
        for (var e : this.getEntities()) {
            if (clazz.isInstance(e)) {
                entities.add((T) e);
            }
        }
        return entities;
    }

    public void sendCancelTelegram(String source, String huident, String mfserror) {
        var tele = this.createTelegram(CANC.class);
        tele.setSource(source);
        tele.setHuident(huident);
        tele.setMfserror(mfserror);
        this.sendTelegram(tele);
    }

    public void sendCancelByTelegram(RoBerTelegram telegram, String mfserror) {
        if (telegram instanceof PORDPalletizingOrder) {
            var tele = (PORDPalletizingOrder) telegram;
            this.sendCancelTelegram(tele.getSource(), tele.getHuident(), mfserror);
        } else if (telegram instanceof DORDDepalletizingOrder) {
            var tele = (PORDPalletizingOrder) telegram;
            this.sendCancelTelegram(tele.getSource(), tele.getHuident(), mfserror);
        } else {
            this.sendCancelTelegram(null, null, mfserror);
        }
    }

    public Item cloneItem(Item item) {
        var entity = item.getEntity();
        var newItem = (Item) item.clone();
        entity.addItem(null, newItem);
        return newItem;
    }

    public void moveItem(final Item item, final Entity destination, long time, boolean retainPosition, AfterAnimation afterAnimation) {
        final var source = item.getEntity();
        item.setMoving(true);
        item.setMoveOutput(destination);
        item.setMoveStartx(item.getPosx());
        item.setMoveStarty(item.getPosy());
        item.setMoveStartz(item.getPosz());
        item.setMoveStopx(destination.getPosx() - source.getPosx() + (retainPosition ? item.getPosx() : 0));
        item.setMoveStopy(destination.getPosy() - source.getPosy() + (retainPosition ? item.getPosy() : 0));
        item.setMoveStopz(destination.getPosz() - source.getPosz() + (retainPosition ? item.getPosz() : 0));
        item.setMoveStartTime(this.core.now());
        item.setMoveStopTime(this.core.now() + time);
        this.addEvent(time, () -> {
            switch (afterAnimation) {
                case Delete:
                    source.delItem(null, item);
                    break;
                
                case OnOutputOnInput:
                    source.onOutput(destination, item);
                    destination.onInput(source, item);
                    this.repositionItems(destination);
                    break;
            }
        });
    }

    public void addEvent(long time, Event event) {
        this.core.addEvent(new com.ssn.simulation.core.Event(this.core.now() + time) {
            @Override
            public void onEvent() {
                event.onEvent();
            }
        });
    }

    @Override
    public Color getBackgroundColor() {
        return this.order != null && this.order.isProcessing() ? this.core.getEntityBusyColor()
                : this.core.getEntityIdleColor();
    }

    public long getProcessingTimePUPO() {
        return processingTimePUPO;
    }

    public long getProcessingTimeDEPO() {
        return processingTimeDEPO;
    }

    public long getProcessingTimeCDOR() {
        return processingTimeCDOR;
    }

    public <T extends RoBerTelegram> T createTelegram(Class<T> clazz) {
        try {
            return clazz.getDeclaredConstructor(ByteHandler.class).newInstance(this.byteHandler);
        } catch (Exception e) {
            this.logError("internal error: " + e.getMessage());
            return null;
        }
    }

    public AbstractConveyor getConveyorById(String roberId) {
        for (var mapping : this.conveyorIdMapping) {
            if (mapping.getRoberId().equals(roberId)) {
                return (AbstractConveyor) this.core.getEntityById(mapping.getConveyorId());
            }
        }
        var entity = this.core.getEntityById(roberId);
        if (!(entity instanceof AbstractConveyor)) {
            this.logError("entity with ID " + roberId + " is not a conveyor");
        } else if (entity instanceof RoBerConveyor
                && !((RoBerConveyor) entity).getRoberResource().equals(this.resource)) {
            this.logError("conveyor " + id + " has not ro-ber resource " + this.resource);
        } else {
            return (AbstractConveyor) entity;
        }
        return null;
    }

    public String getPalletCoverConveyor() {
        return palletCoverConveyor;
    }

    public double getBinSizey() {
        return binSizey;
    }

    public double getBinSizez() {
        return binSizez;
    }

    public double getBinSizex() {
        return binSizex;
    }

    public void repositionItems(Entity entity, List<Item> items) {
        final var gap = 0.05;

        var entityRotation = entity.getRotation() % 180;
        var totalSize = (items.size() - 1) * gap;
        for (var item : items) {
            totalSize += (item.getRotation() % 180) == entityRotation ? item.getSizex() : item.getSizey();
        }
        var pos = -totalSize / 2;
        for (var item : items) {
            var itemSize = item.getRotation() % 180 == entityRotation ? item.getSizex() : item.getSizey();
            var itemPos = pos + itemSize / 2;
            pos += itemSize + gap;
            if (entityRotation == 0) {
                item.setPosx(itemPos);
            } else {
                item.setPosy(itemPos);
            }
        }
    }

    public void repositionItems(Entity entity) {
        this.repositionItems(entity, entity.getItems());
    }
}
