package com.ssn.simulation.entities.rober;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;
import java.awt.GridLayout;

import com.ssn.simulation.dialogs.PalletConveyorRuntimeDialog;
import com.ssn.simulation.entities.PalletConveyor;
import com.ssn.simulation.items.Pallet;
import com.ssn.simulation.utils.DialogUtils;
import com.ssn.simulation.utils.OpcuaUtils;
import com.ssn.simulation.editor.DoubleProperty;
import com.ssn.simulation.editor.IntegerProperty;
import com.ssn.simulation.core.Item;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.util.List;

public class RoberConveyorRuntimeDialog extends PalletConveyorRuntimeDialog {

    public RoberConveyorRuntimeDialog(JFrame parent) {
        super(parent);
    }

    @Override
    public JPanel createPalletPanel() {
        JButton createButton = DialogUtils.createButton("Create new pallet", new ActionListener() {
            public synchronized void actionPerformed(ActionEvent e) {
                final Pallet pallet = new Pallet(RoberConveyorRuntimeDialog.this.entity.getCore());
                pallet.setId(RoberConveyorRuntimeDialog.this.idInput.getText());
                pallet.setType(IntegerProperty.parseInteger(RoberConveyorRuntimeDialog.this.typeInput.getText(), 0));
                pallet.setSizex(DoubleProperty.parseDouble(RoberConveyorRuntimeDialog.this.sizexInput.getText(), 1.2D));
                pallet.setSizey(DoubleProperty.parseDouble(RoberConveyorRuntimeDialog.this.sizeyInput.getText(), 0.8D));
                pallet.setSizez(DoubleProperty.parseDouble(RoberConveyorRuntimeDialog.this.sizezInput.getText(), 1.0D));
                pallet.setEmpty(RoberConveyorRuntimeDialog.this.emptyInput.isSelected());
                pallet.setStack(RoberConveyorRuntimeDialog.this.stackInput.isSelected());
                pallet.setCage(RoberConveyorRuntimeDialog.this.cageInput.isSelected());
                pallet.setOneway(RoberConveyorRuntimeDialog.this.onewayInput.isSelected());
                pallet.setUnderlayed(RoberConveyorRuntimeDialog.this.underlayedInput.isSelected());
                pallet.setWidth(IntegerProperty.parseInteger(RoberConveyorRuntimeDialog.this.widthInput.getText(), 0));
                pallet.setLength(IntegerProperty.parseInteger(RoberConveyorRuntimeDialog.this.lengthInput.getText(), 0));
                pallet.setHeight(IntegerProperty.parseInteger(RoberConveyorRuntimeDialog.this.heightInput.getText(), 0));
                pallet.setWeight(IntegerProperty.parseInteger(RoberConveyorRuntimeDialog.this.weightInput.getText(), 0));
                pallet.setRotation(
                        DoubleProperty.parseDouble(RoberConveyorRuntimeDialog.this.rotationInput.getText(), 0.0D));
                pallet.setAnnounced(false);
                RoberConveyorRuntimeDialog.this.entity.getCore().addExternalEvent(new Runnable() {
                    public void run() {
                        PalletConveyor conveyor = (PalletConveyor) RoberConveyorRuntimeDialog.this.entity;
                        if (conveyor.readyForExternalInput((Item) pallet)) {
                            conveyor.setCreateNotifictaion(false);
                            conveyor.onInput(null, (Item) pallet);
                        } else {
                            conveyor.getCore().logError(conveyor,
                                    "unable to create pallet, entity not ready for input");
                        }
                    }
                });
                RoberConveyorRuntimeDialog.this.getAnimation().refresh();
            }
        });
        JButton destroyButton = DialogUtils.createButton("Destroy current pallet", new ActionListener() {
            public synchronized void actionPerformed(ActionEvent e) {
                    RoberConveyorRuntimeDialog.this.entity.getCore().addExternalEvent(new Runnable() {
                        public void run() {
                            PalletConveyor conveyor = (PalletConveyor) RoberConveyorRuntimeDialog.this.entity;
                            Item item = conveyor.getFirstItem();
                            conveyor.setDeleteNotifictaion(false);
                            if (conveyor.readyForExternalOutput(item)) {
                                conveyor.onOutput(null, item);
                            } else {
                                conveyor.getCore().logError(conveyor,
                                        "unable to destroy pallet, entity not ready for output");
                            }
                            conveyor.setDeleteNotifictaion(false);
                        }
                    });
                    RoberConveyorRuntimeDialog.this.getAnimation().refresh();
            }
        });
        JButton errorOnButton = DialogUtils.createButton("Error on", new ActionListener() {
            public synchronized void actionPerformed(ActionEvent e) {
                final PalletConveyor conveyor = (PalletConveyor) RoberConveyorRuntimeDialog.this.entity;
                final List<OpcuaUtils.OpcuaAlert> alerts = conveyor.loadOpcuaAlerts();
                OpcuaUtils.confirmOpcuaAlerts(null, conveyor.getMechanicalName(), alerts);
                RoberConveyorRuntimeDialog.this.entity.getCore().addExternalEvent(new Runnable() {
                    public void run() {
                        conveyor.onErrorOn(new Object[0]);
                        conveyor.handleOpcuaAlertUpdate(alerts);
                        conveyor.triggerEntity();
                        conveyor.triggerInputs();
                        conveyor.triggerObservers();
                    }
                });
                RoberConveyorRuntimeDialog.this.getAnimation().refresh();
            }
        });
        JButton errorOffButton = DialogUtils.createButton("Error off", new ActionListener() {
            public synchronized void actionPerformed(ActionEvent e) {
                final PalletConveyor conveyor = (PalletConveyor) RoberConveyorRuntimeDialog.this.entity;
                final List<OpcuaUtils.OpcuaAlert> alerts = conveyor.loadOpcuaAlerts();
                OpcuaUtils.resetOpcuaAlerts(alerts);
                RoberConveyorRuntimeDialog.this.entity.getCore().addExternalEvent(new Runnable() {
                    public void run() {
                        conveyor.onErrorOff(new Object[0]);
                        conveyor.handleOpcuaAlertUpdate(alerts);
                        conveyor.triggerEntity();
                        conveyor.triggerInputs();
                        conveyor.triggerObservers();
                    }
                });
                RoberConveyorRuntimeDialog.this.getAnimation().refresh();
            }
        });
        this.idInput = new JTextField("Pallet");
        this.typeInput = new JTextField("101");
        this.sizexInput = new JTextField("1.2");
        this.sizeyInput = new JTextField("0.8");
        this.sizezInput = new JTextField("1.0");
        this.emptyInput = new JCheckBox();
        this.emptyInput.setBorder(BorderFactory.createEmptyBorder());
        this.stackInput = new JCheckBox();
        this.stackInput.setBorder(BorderFactory.createEmptyBorder());
        this.cageInput = new JCheckBox();
        this.cageInput.setBorder(BorderFactory.createEmptyBorder());
        this.onewayInput = new JCheckBox();
        this.onewayInput.setBorder(BorderFactory.createEmptyBorder());
        this.underlayedInput = new JCheckBox();
        this.underlayedInput.setBorder(BorderFactory.createEmptyBorder());
        this.widthInput = new JTextField("0");
        this.lengthInput = new JTextField("0");
        this.heightInput = new JTextField("0");
        this.weightInput = new JTextField("0");
        this.rotationInput = new JTextField("0");
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(21, 1, 5, 5));
        panel.add(DialogUtils.createLabelledComponent("Pallet Id:", this.idInput));
        panel.add(DialogUtils.createLabelledComponent("Pallet Type:", this.typeInput));
        panel.add(DialogUtils.createLabelledComponent("Pallet Sizex:", this.sizexInput));
        panel.add(DialogUtils.createLabelledComponent("Pallet Sizey:", this.sizeyInput));
        panel.add(DialogUtils.createLabelledComponent("Pallet Sizez:", this.sizezInput));
        panel.add(DialogUtils.createLabelledComponent("Pallet Empty:", this.emptyInput));
        panel.add(DialogUtils.createLabelledComponent("Pallet Stack:", this.stackInput));
        panel.add(DialogUtils.createLabelledComponent("Pallet Cage:", this.cageInput));
        panel.add(DialogUtils.createLabelledComponent("Pallet Oneway:", this.onewayInput));
        panel.add(DialogUtils.createLabelledComponent("Pallet Underlayed:", this.underlayedInput));
        panel.add(DialogUtils.createLabelledComponent("Pallet Width:", this.widthInput));
        panel.add(DialogUtils.createLabelledComponent("Pallet Length:", this.lengthInput));
        panel.add(DialogUtils.createLabelledComponent("Pallet Height:", this.heightInput));
        panel.add(DialogUtils.createLabelledComponent("Pallet Weight:", this.weightInput));
        panel.add(DialogUtils.createLabelledComponent("Pallet Rotation:", this.rotationInput));
        panel.add(createButton);
        panel.add(destroyButton);
        panel.add(errorOnButton);
        panel.add(errorOffButton);
        return panel;
    }
}
