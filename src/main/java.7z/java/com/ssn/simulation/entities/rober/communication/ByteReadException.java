package com.ssn.simulation.entities.rober.communication;

public class ByteReadException extends Exception {
    public ByteReadException(String errorMessage) {
        super(errorMessage);
    }
}