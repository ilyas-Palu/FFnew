package com.ssn.simulation.entities.rober.communication;

public class TelegramHeaderFields {
    public static final String HANDSHAKEK_DATA_TEL = "D";
    public static final String HANDSHAKE_ACK_TEL = "Q";

    @TelegramField(offset = 0, length = 8, type = TelegramFieldType.CHAR)
    protected String sender;

    @TelegramField(offset = 8, length = 8, type = TelegramFieldType.CHAR)
    protected String receiver;

    @TelegramField(offset = 16, length = 2, type = TelegramFieldType.CHAR)
    protected String handshake;

    @TelegramField(offset = 18, length = 4, type = TelegramFieldType.NUMC)
    protected int seqno;

    @TelegramField(offset = 22, length = 4, type = TelegramFieldType.CHAR)
    protected String comm_error;

    @TelegramField(offset = 26, length = 4, type = TelegramFieldType.CHAR)
    protected String teletype;

    @TelegramField(offset = 30, length = 18, type = TelegramFieldType.CHAR)
    protected String resource;

    public boolean isDataTel() {
        return this.handshake.equals(HANDSHAKEK_DATA_TEL);
    }

    public boolean isAckTel() {
        return this.handshake.equals(HANDSHAKE_ACK_TEL);
    }

    public static String getHandshakekDataTel() {
        return HANDSHAKEK_DATA_TEL;
    }

    public static String getHandshakeAckTel() {
        return HANDSHAKE_ACK_TEL;
    }

    public String getSender() {
        return sender;
    }

    public void setSender(String sender) {
        this.sender = sender;
    }

    public String getReceiver() {
        return receiver;
    }

    public void setReceiver(String receiver) {
        this.receiver = receiver;
    }

    public String getHandshake() {
        return handshake;
    }

    public void setHandshake(String handshake) {
        this.handshake = handshake;
    }

    public int getSeqno() {
        return seqno;
    }

    public void setSeqno(int seqno) {
        this.seqno = seqno;
    }

    public String getComm_error() {
        return comm_error;
    }

    public void setComm_error(String comm_error) {
        this.comm_error = comm_error;
    }

    public String getTeletype() {
        return teletype;
    }

    public void setTeletype(String teletype) {
        this.teletype = teletype;
    }

    public String getResource() {
        return resource;
    }

    public void setResource(String resource) {
        this.resource = resource;
    }
}