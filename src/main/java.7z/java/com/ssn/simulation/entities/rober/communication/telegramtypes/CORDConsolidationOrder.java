package com.ssn.simulation.entities.rober.communication.telegramtypes;

import com.ssn.simulation.entities.rober.communication.ByteHandler;
import com.ssn.simulation.entities.rober.communication.TelegramField;
import com.ssn.simulation.entities.rober.communication.TelegramFieldType;

public class CORDConsolidationOrder extends RoBerTelegram {
    public static final String TELETYPE = "CORD";

    @TelegramField(offset = 48, length = 4, type = TelegramFieldType.CHAR)
    protected String mfserror;

    public CORDConsolidationOrder(ByteHandler byteHandler) {
        super(byteHandler);
    }

    @Override
    public String getTelegramType() {
        return TELETYPE;
    }

    public String getMfserror() {
        return mfserror;
    }    
}
