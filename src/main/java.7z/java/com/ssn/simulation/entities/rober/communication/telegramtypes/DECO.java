package com.ssn.simulation.entities.rober.communication.telegramtypes;

import com.ssn.simulation.entities.rober.communication.ByteHandler;
import com.ssn.simulation.entities.rober.communication.TelegramField;
import com.ssn.simulation.entities.rober.communication.TelegramFieldType;

public class DECO extends RoBerTelegram {
    public static final String TELETYPE = "DECO";

    @TelegramField(offset = 48, length = 18, type = TelegramFieldType.CHAR)
    protected String source;

    @TelegramField(offset = 66, length = 18, type = TelegramFieldType.CHAR)
    protected String destination;

    @TelegramField(offset = 84, length = 20, type = TelegramFieldType.CHAR)
    protected String huident;

    @TelegramField(offset = 104, length = 1, type = TelegramFieldType.BOOLEAN)
    protected boolean last;

    @TelegramField(offset = 105, length = 4, type = TelegramFieldType.CHAR)
    protected String mfserror;

    public DECO(ByteHandler byteHandler) {
        super(byteHandler);
    }

    @Override
    public String getTelegramType() {
        return TELETYPE;
    }

    public static String getTeletype() {
        return TELETYPE;
    }

    public String getSource() {
        return source;
    }

    public String getDestination() {
        return destination;
    }

    public String getHuident() {
        return huident;
    }

    public String getMfserror() {
        return mfserror;
    }

    public boolean getLast() {
        return last;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }

    public void setHuident(String huident) {
        this.huident = huident;
    }

    public void setLast(boolean last) {
        this.last = last;
    }

    public void setMfserror(String mfserror) {
        this.mfserror = mfserror;
    }
}
