package com.ssn.simulation.entities.rober.communication.telegramtypes;

import com.ssn.simulation.entities.rober.communication.ByteHandler;
import com.ssn.simulation.entities.rober.communication.TelegramField;
import com.ssn.simulation.entities.rober.communication.TelegramFieldType;

public class DORDDepalletizingOrder extends RoBerTelegram {
    public static final String TELETYPE = "DORD";

    @TelegramField(offset = 48, length = 18, type = TelegramFieldType.CHAR)
    protected String source;

    @TelegramField(offset = 66, length = 20, type = TelegramFieldType.CHAR)
    protected String huident;

    @TelegramField(offset = 86, length = 8, type = TelegramFieldType.CHAR)
    protected String hutyp;

    @TelegramField(offset = 98, length = 3, type = TelegramFieldType.NUMC)
    protected int hucount;

    @TelegramField(offset = 101, length = 3, type = TelegramFieldType.NUMC)
    protected int layers;

    @TelegramField(offset = 104, length = 4, type = TelegramFieldType.CHAR)
    protected String mfserror;

    public DORDDepalletizingOrder(ByteHandler byteHandler) {
        super(byteHandler);
    }

    @Override
    public String getTelegramType() {
        return TELETYPE;
    }

    public String getSource() {
        return source;
    }

    public String getHuident() {
        return huident;
    }

    public String getHutyp() {
        return hutyp;
    }

    public int getHuCount() {
        return hucount;
    }

    public String getMfserror() {
        return mfserror;
    }

    public static String getTeletype() {
        return TELETYPE;
    }

    public int getLayers() {
        return layers;
    }    
}
