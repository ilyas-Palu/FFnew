package com.ssn.simulation.entities.rober.communication.telegramtypes;

import com.ssn.simulation.entities.rober.communication.ByteHandler;
import com.ssn.simulation.entities.rober.communication.TelegramField;
import com.ssn.simulation.entities.rober.communication.TelegramFieldType;

public class LLFTCommunicationPointLeft extends RoBerTelegram {
    public static final String TELETYPE = "LLFT";

    @TelegramField(offset = 48, length = 18, type = TelegramFieldType.CHAR)
    protected String source;

    @TelegramField(offset = 66, length = 20, type = TelegramFieldType.CHAR)
    protected String huident;

    @TelegramField(offset = 86, length = 1, type = TelegramFieldType.BOOLEAN)
    protected boolean completed;

    @TelegramField(offset = 87, length = 4, type = TelegramFieldType.CHAR)
    protected String mfserror;

    public LLFTCommunicationPointLeft(ByteHandler byteHandler) {
        super(byteHandler);
    }

    @Override
    public String getTelegramType() {
        return TELETYPE;
    }
    
    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getHuident() {
        return huident;
    }

    public void setHuident(String huident) {
        this.huident = huident;
    }

    public boolean isCompleted() {
        return completed;
    }

    public void setCompleted(boolean completed) {
        this.completed = completed;
    }

    public String getMfserror() {
        return mfserror;
    }

    public void setMfserror(String mfserror) {
        this.mfserror = mfserror;
    }
}
