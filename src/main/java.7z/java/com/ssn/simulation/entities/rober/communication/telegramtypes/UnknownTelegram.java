package com.ssn.simulation.entities.rober.communication.telegramtypes;

import com.ssn.simulation.entities.rober.communication.ByteHandler;

public class UnknownTelegram extends RoBerTelegram {

    public UnknownTelegram(ByteHandler byteHandler) {
        super(byteHandler);
    }

    @Override
    public String getTelegramType() {
        return this.header.getTeletype();
    }
}
