package com.ssn.simulation.entities.rober.orders;

import com.ssn.simulation.entities.rober.RoBerException;

import java.util.ArrayList;

import com.ssn.simulation.core.Item;
import com.ssn.simulation.entities.AbstractConveyor;
import com.ssn.simulation.entities.rober.AfterAnimation;
import com.ssn.simulation.entities.rober.RoBerController;
import com.ssn.simulation.entities.rober.communication.telegramtypes.CANC;
import com.ssn.simulation.entities.rober.communication.telegramtypes.CDCO;
import com.ssn.simulation.entities.rober.communication.telegramtypes.CDOR;
import com.ssn.simulation.entities.rober.communication.telegramtypes.COCOConsolidationOrderConfirmation;
import com.ssn.simulation.entities.rober.communication.telegramtypes.CORDConsolidationOrder;
import com.ssn.simulation.entities.rober.communication.telegramtypes.RoBerTelegram;

public class ConsolidationOrder extends RoBerOrder {
    enum Step {
        HU1,
        HU2,
        CONSOLIDATE,
        MOVE_BACK,
        FINISH
    }

    protected CORDConsolidationOrder order;
    protected Step step;

    public ConsolidationOrder(RoBerController controller, CORDConsolidationOrder order) {
        super(controller);
        this.order = order;
        this.step = Step.HU1;
    }

    @Override
    public void startOrder() {
    }

    @Override
    public RoBerTelegram buildOrderStartConfirmation() {
        var coco = this.controller.createTelegram(COCOConsolidationOrderConfirmation.class);
        coco.setMfserror(this.order.getMfserror());
        return coco;
    }

    @Override
    public void handleTelegram(RoBerTelegram telegram) throws RoBerException {
        if (!(telegram instanceof CDOR)) {
            this.sendOSTA(null, null, "MWOT");
            throw new RoBerException("invalid telegram type " + telegram.getTelegramType() + " for mode consolidation");
        }
        var cdor = (CDOR)telegram;
        switch (this.step) {
            case HU1:
                this.moveHU(cdor, getConv(cdor.getSource(), true), getConv(cdor.getDestination(), false), false);
                this.step = Step.HU2;
                break;

            case HU2:
                this.moveHU(cdor, getConv(cdor.getSource(), true), getConv(cdor.getDestination(), true), false);
                this.step = Step.CONSOLIDATE;
                break;

            case CONSOLIDATE:
                this.consolidate(cdor);
                this.step = Step.MOVE_BACK;
                break;

            case MOVE_BACK:
                this.moveHU(cdor, getConv(cdor.getSource(), true), getConv(cdor.getDestination()), true);
                this.step = Step.FINISH;
                break;

            case FINISH:
                throw new RoBerException("internal state invalid");
        }
        this.processing = true;
    }

    @Override
    public void cancelOrder(CANC telegram) throws RoBerException {
        this.controller.setOrder(null);
    }

    protected void moveHU(CDOR cdor, AbstractConveyor source, AbstractConveyor dest, boolean moveSource) throws RoBerException {
        this.processing = true;
        var processingTime = this.controller.getProcessingTimeCDOR();
        var items = new ArrayList<Item>(source.getItems());
        if (!moveSource) {
            var item = items.get(0);
            item = this.controller.cloneItem(item);
            item.setId(cdor.getHuident1());
            items.clear();
            items.add(item);
        }
        for (var item : items) {
            this.controller.moveItem(item, dest, processingTime, false, moveSource ? AfterAnimation.Delete : AfterAnimation.OnOutputOnInput);
        }
        this.controller.addEvent(processingTime, () -> this.onMoveDone(cdor));
    }

    protected void onMoveDone(CDOR cdor) {
        this.processing = false;
        CDCO cdco = this.controller.createTelegram(CDCO.class);
        cdco.setSource(cdor.getSource());
        cdco.setDestination(cdor.getDestination());
        cdco.setHuident1(cdor.getHuident1());
        cdco.setHuident2(cdor.getHuident2());
        cdco.setHutyp(cdor.getHutyp());
        this.controller.sendTelegram(cdco);

        if (this.step == Step.FINISH) {
            this.controller.setOrder(null);
        }
    }

    protected void consolidate(CDOR cdor) throws RoBerException {
        if (!cdor.getConsolidate()) {
            throw new RoBerException("exptected flag \"consolidate\" in telegram but it is not set");
        }
        var processingTime = this.controller.getProcessingTimeCDOR();

        this.processing = true;
        this.controller.addEvent(processingTime, () -> {
            this.processing = false;
            CDCO cdco = this.controller.createTelegram(CDCO.class);
            cdco.setConsolidate(cdor.getConsolidate());
            cdco.setHuident1(cdor.getHuident1());
            cdco.setHuident2(cdor.getHuident2());
            this.controller.sendTelegram(cdco);
        });
    }

    
}
