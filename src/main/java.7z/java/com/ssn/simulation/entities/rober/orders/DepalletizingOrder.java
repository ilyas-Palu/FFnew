package com.ssn.simulation.entities.rober.orders;

import com.ssn.simulation.entities.rober.RoBerException;
import com.ssn.simulation.entities.rober.AfterAnimation;
import com.ssn.simulation.entities.rober.RoBerController;
import com.ssn.simulation.entities.rober.RoBerConveyor;
import com.ssn.simulation.entities.rober.communication.telegramtypes.CANC;
import com.ssn.simulation.entities.rober.communication.telegramtypes.DECO;
import com.ssn.simulation.entities.rober.communication.telegramtypes.DEPO;
import com.ssn.simulation.entities.rober.communication.telegramtypes.DOCODepalletizingOrderConfirmation;
import com.ssn.simulation.entities.rober.communication.telegramtypes.DORDDepalletizingOrder;
import com.ssn.simulation.entities.rober.communication.telegramtypes.RoBerTelegram;

public class DepalletizingOrder extends RoBerOrder {
    protected DORDDepalletizingOrder order;
    protected int remaining;

    public DepalletizingOrder(RoBerController controller, DORDDepalletizingOrder order) {
        super(controller);
        this.order = order;
    }

    @Override
    public void startOrder() throws RoBerException {
        var conveyor = this.getConv(this.order.getSource(), true);
        var item = conveyor.getFirstItem();
        item.setId(this.order.getHuident());
        this.remaining = this.order.getHuCount();
        if (this.remaining == 0) {
            throw new RoBerException("number of HUs to depalletize is zero");
        }
    }

    @Override
    public RoBerTelegram buildOrderStartConfirmation() {
        var doco = this.controller.createTelegram(DOCODepalletizingOrderConfirmation.class);
        doco.setSource(this.order.getSource());
        doco.setHuident(this.order.getHuident());
        doco.setHutyp(this.order.getHutyp());
        doco.setHuCount(this.order.getHuCount());
        doco.setLayers(this.order.getLayers());
        doco.setMfserror(this.order.getMfserror());
        return doco;
    }

    @Override
    public void handleTelegram(RoBerTelegram telegram) throws RoBerException {
        if (!(telegram instanceof DEPO)) {
            this.sendOSTA(null, null, "MWOT");
            throw new RoBerException("invalid telegram type " + telegram.getTelegramType() + " for mode depalletising");
        }
        var depo = (DEPO)telegram;
        var source = this.getConv(depo.getSource(), true);
        var dest = this.getConv(depo.getDestination());
        this.processing = true;
        var pallet = source.getFirstItem();
        final var item = this.controller.cloneItem(pallet);

        item.setSizex(this.controller.getBinSizex());
        item.setSizey(this.controller.getBinSizey());
        item.setSizez(this.controller.getBinSizez());
        item.setId(depo.getHuident());

        var processingTime = this.controller.getProcessingTimeDEPO();
        this.controller.moveItem(item, dest, processingTime, false, AfterAnimation.Delete);
        this.controller.addEvent(processingTime, () -> {
            this.processing = false;
            var deco = this.controller.createTelegram(DECO.class);
            deco.setSource(depo.getSource());
            deco.setDestination(depo.getDestination());
            deco.setHuident(depo.getHuident());
            if (--this.remaining == 0) {
                deco.setLast(true);
                this.finish(true);
            }
            this.controller.sendTelegram(deco);
        });
    }

    private void finish(boolean complete) {
        this.controller.setOrder(null);
        var conv = this.controller.getConveyorById(this.order.getSource());
        var item = conv.getFirstItem();
        if (item != null) {
            item.setBooleanTag(RoBerOrder.TAG_COMPLETED, complete);
        }
        if (conv instanceof RoBerConveyor) {
            ((RoBerConveyor)conv).moveItem();
        }
    }

    @Override
    public void cancelOrder(CANC telegram) throws RoBerException {
        this.finish(false);
    }

}
