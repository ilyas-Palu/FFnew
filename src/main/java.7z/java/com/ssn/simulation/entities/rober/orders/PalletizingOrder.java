package com.ssn.simulation.entities.rober.orders;

import com.ssn.simulation.entities.rober.RoBerException;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.ssn.simulation.core.Item;
import com.ssn.simulation.entities.AbstractConveyor;
import com.ssn.simulation.entities.rober.AfterAnimation;
import com.ssn.simulation.entities.rober.RoBerController;
import com.ssn.simulation.entities.rober.RoBerConveyor;
import com.ssn.simulation.entities.rober.communication.telegramtypes.CANC;
import com.ssn.simulation.entities.rober.communication.telegramtypes.POCOPalletizingOrderConfirmation;
import com.ssn.simulation.entities.rober.communication.telegramtypes.PORDPalletizingOrder;
import com.ssn.simulation.entities.rober.communication.telegramtypes.PUCO;
import com.ssn.simulation.entities.rober.communication.telegramtypes.PUPO;
import com.ssn.simulation.entities.rober.communication.telegramtypes.RoBerTelegram;
import com.ssn.simulation.entities.rober.telegramHandlers.APNO;

public class PalletizingOrder extends RoBerOrder {
    protected PORDPalletizingOrder order;
    protected Map<Integer,Integer> griptypes;
    protected List<PUPO> pupoTelegrams = new ArrayList<PUPO>();
    protected int pupoTelegramsHuCount = 0;

    public PalletizingOrder(RoBerController controller, PORDPalletizingOrder order) {
        super(controller);
        this.order = order;

        this.griptypes = Map.of(1,2, 2,4, 3,3, 4,2);
    }

    @Override
    public void startOrder() throws RoBerException {
        var source = this.getConv(this.order.getSource(), true);
        var dest = this.getConv(this.order.getDestination(), false);
        var item = source.getFirstItem();
        var processingTime = source instanceof RoBerConveyor ? ((RoBerConveyor)source).getProcessingTime() : 1000;

        item.setBooleanTag(RoBerOrder.TAG_COMPLETED, false);
        var stacksize = item.getIntegerTag(APNO.TAG_STACKSIZE);
        this.controller.addEvent(processingTime, () -> { this.processing = false; });
        if (stacksize > 1) {
            item.setIntegerTag(APNO.TAG_STACKSIZE, stacksize - 1);
            var newItem = this.controller.cloneItem(item);
            newItem.delTag(APNO.TAG_STACKSIZE);
            newItem.setId(this.order.getHuident());
            newItem.getEntity().moveItem(dest, newItem, processingTime);
        } else {
            item.delTag(APNO.TAG_STACKSIZE);
            source.moveItem(dest, item, processingTime);
        }
    }

    @Override
    public RoBerTelegram buildOrderStartConfirmation() {
        var poco = this.controller.createTelegram(POCOPalletizingOrderConfirmation.class);
        poco.setSource(this.order.getSource());
        poco.setDestination(this.order.getDestination());
        poco.setHuident(this.order.getHuident());
        poco.setHutyp(this.order.getHutyp());
        poco.setAlternating(this.order.getAlternating());
        poco.setPalletCover(this.order.getPalletCover());
        poco.setMfserror(this.order.getMfserror());
        return poco;
    }

    @Override
    public void handleTelegram(RoBerTelegram telegram) throws RoBerException {
        if (!(telegram instanceof PUPO)) {
            this.sendOSTA(null, null, "MWOT");
            throw new RoBerException("invalid telegram type " + telegram.getTelegramType() + " for mode palletising");
        }
        var tele = (PUPO)telegram;
        var husInTele = tele.getHuident2() != null && !tele.getHuident2().isEmpty() ? 2 : 1;
        var source = this.getConv(tele.getSource(), true);
        var item = source.getFirstItem();
        var gripsize = this.griptypes.get(tele.getGriptype());
        if (gripsize == null) {
            throw new RoBerException("invalid grip type " + tele.getGriptype() + " in telegram");
        }
        var isOrderDest = this.order.getDestination().equals(tele.getDestination());
        var destination = this.getConv(tele.getDestination(), isOrderDest ? true : null);
        var isGripComplete = (isOrderDest ? source.getItems().size() : destination.getItems().size() + husInTele) == gripsize;
        if (!isOrderDest) {
            if (destination.getItems().size() + husInTele > gripsize) {
                throw new RoBerException("too many items for grip type "+ tele.getGriptype());
            }
            List<Item> newItems = new ArrayList<Item>();
            for (var i=0; i<husInTele; ++i) {
                var movingItem = this.controller.cloneItem(item);
                movingItem.setId(tele.getHuident1());
                movingItem.setRotation(tele.getRotation() * 90);
                newItems.add(movingItem);
            }
            this.controller.repositionItems(source, newItems);
            for (var movingItem : newItems) {
                this.controller.moveItem(movingItem, destination, this.controller.getProcessingTimePUPO(), true, AfterAnimation.OnOutputOnInput);
            }
            this.controller.addEvent(this.controller.getProcessingTimePUPO(), () -> { this.onPupoDone(tele); });
            //source.moveItem(destination, movingItem, this.controller.getProcessingTimePUPO());
        } else if (pupoTelegramsHuCount < gripsize) {
            this.pupoTelegrams.add(tele);
            this.pupoTelegramsHuCount += husInTele;
        } else {
            throw new RoBerException("too many PUPO telegrams for grip type " + tele.getGriptype() + " in buffer");
        }

        if (tele.isLast() || (isGripComplete && pupoTelegramsHuCount == gripsize)) {
            for (var sourceItem : source.getItems()) {
                this.controller.moveItem(sourceItem, destination, this.controller.getProcessingTimePUPO(), true, AfterAnimation.Delete);
            }
            for (var pupo : this.pupoTelegrams) {
                this.controller.addEvent(this.controller.getProcessingTimePUPO(), () -> { this.onPupoDone(pupo); });
            }
        }
    }

    protected void onPupoDone(PUPO pupo) {
        this.processing = false;

        var puco = this.controller.createTelegram(PUCO.class);
        puco.setSource(pupo.getSource());
        puco.setDestination(pupo.getDestination());
        puco.setHuident1(pupo.getHuident1());
        puco.setHuident2(pupo.getHuident2());
        this.controller.sendTelegram(puco);
        if (pupo.getDestination().equals(this.order.getDestination())) {
            this.pupoTelegrams.clear();
            this.pupoTelegramsHuCount = 0;
        }
        if (!pupo.isLast()) {
            return;
        }
        if (this.order.getPalletCover()) {
            this.doPalletCover(pupo);
            return;
        }
        this.finishOrder();
    }

    private void finishOrder() {
        this.controller.setOrder(null);
        try {
            var conveyor = this.getRoBerConveyor(this.order.getDestination());
            var item = conveyor.getFirstItem();
            item.setBooleanTag(RoBerOrder.TAG_COMPLETED, true);
            conveyor.moveItem();
        } catch(Exception e) {
            this.controller.logError(e.getMessage());
        }
    }

    private void doPalletCover(PUPO pupo) {
        var conveyorId = this.controller.getPalletCoverConveyor();
        if (conveyorId == null || conveyorId.isEmpty()) {
            this.controller.logError("no conveyor for pallet covers configured");
            return;
        }
        AbstractConveyor coverConveyor;
        AbstractConveyor dest;
        try {
            coverConveyor = this.getConv(conveyorId, true);
            dest = this.getConv(this.order.getDestination(), "MNTC");
        } catch (Exception e) {
            this.controller.logError("pallet cover error: " + e.getMessage());
            return;
        }
        this.processing = true;

        var processingTime = coverConveyor instanceof RoBerConveyor ? ((RoBerConveyor)coverConveyor).getProcessingTime() : 1000;
        var item = coverConveyor.getFirstItem();
        var stacksize = item.getIntegerTag(APNO.TAG_STACKSIZE);

        if (stacksize > 1) {
            item.setIntegerTag(APNO.TAG_STACKSIZE, stacksize - 1);
            var newItem = this.controller.cloneItem(item);
            newItem.delTag(APNO.TAG_STACKSIZE);
            newItem.setId(this.order.getHuident());
            item = newItem;
            this.controller.moveItem(item, dest, processingTime, false, AfterAnimation.Delete);
        } else {
            item.delTag(APNO.TAG_STACKSIZE);
            coverConveyor.moveItem(dest, item, processingTime);
            this.controller.moveItem(item, dest, processingTime, false, AfterAnimation.Delete);
        }
        this.controller.addEvent(processingTime, () -> {
            this.processing = false;
            this.finishOrder();
        });
    }

    @Override
    public void cancelOrder(CANC telegram) throws RoBerException {
        this.controller.setOrder(null);
        var conveyor = this.getRoBerConveyor(this.order.getDestination());
        if (conveyor.hasItem()) {
            conveyor.moveItem();
        }
    }

}
