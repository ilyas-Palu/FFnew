package com.ssn.simulation.entities.rober.orders;

import com.ssn.simulation.entities.AbstractConveyor;
import com.ssn.simulation.entities.rober.RoBerConveyor;
import com.ssn.simulation.entities.rober.RoBerException;
import com.ssn.simulation.entities.rober.RoBerController;
import com.ssn.simulation.entities.rober.communication.telegramtypes.CANC;
import com.ssn.simulation.entities.rober.communication.telegramtypes.RoBerTelegram;

public abstract class RoBerOrder {
    public static final String TAG_COMPLETED = "roberCompleted";

    protected RoBerController controller;
    protected boolean processing;

    public RoBerOrder(RoBerController controller) {
        this.controller = controller;
    }

    public AbstractConveyor getConveyor(String id) throws RoBerException {
        if (id == null || id.isEmpty()) {
            throw new RoBerException("invalid telegram -> no conveyor given");
        }
        var conveyor = this.controller.getConveyorById(id);
        if (conveyor == null) {
            throw new RoBerException("invalid conveyor " + id + " in telegram");
        }
        return conveyor;
    }

    public RoBerConveyor getRoBerConveyor(String id) throws RoBerException {
        var conveyor = this.getConveyor(id);
        if (conveyor instanceof RoBerConveyor) {
            return (RoBerConveyor)conveyor;
        }
        throw new RoBerException("conveyor " + id + " is not a RoBerConveyor");
    }

    public boolean isProcessing() {
        return this.processing;
    }

    protected AbstractConveyor getConv(String id, Boolean itemExpected, String mfserror) throws RoBerException {
        var conveyor = this.controller.getConveyorById(id);
        if (conveyor == null) {
            this.sendOSTA(id, null, "MSDW");
            throw new RoBerException("conveyor " + id + " not found");
        }
        if (itemExpected != null && itemExpected && !conveyor.hasItem()) {
            this.sendOSTA(id, null, mfserror);
            throw new RoBerException("no item on conveyor " + id);
        } else if (itemExpected != null && !itemExpected && conveyor.hasItem()) {
            throw new RoBerException("no item on conveyor " + id + " expected but conveyor has an item");
        }
        return conveyor;
    }

    protected AbstractConveyor getConv(String id, Boolean itemExpected) throws RoBerException {
        return this.getConv(id, itemExpected, "MPOE");
    }

    protected AbstractConveyor getConv(String id, String mfserror) throws RoBerException {
        return this.getConv(id, true, mfserror);
    }

    protected AbstractConveyor getConv(String id) throws RoBerException {
        return this.getConv(id, null, "MPOE");
    }

    protected void sendOSTA(String source, String huident, String mfserror) {
        this.controller.sendOSTA(source, huident, mfserror);
    }
    
    public abstract void startOrder() throws RoBerException;
    public abstract void handleTelegram(RoBerTelegram telegram) throws RoBerException;
    public abstract void cancelOrder(CANC telegram) throws RoBerException;
    public abstract RoBerTelegram buildOrderStartConfirmation();
}
