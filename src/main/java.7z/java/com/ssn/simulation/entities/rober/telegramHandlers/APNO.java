package com.ssn.simulation.entities.rober.telegramHandlers;

import com.ssn.simulation.entities.rober.RoBerConveyor;
import com.ssn.simulation.entities.rober.RoBerException;
import com.ssn.simulation.entities.rober.RoBerController;
import com.ssn.simulation.entities.rober.communication.telegramtypes.APNOAnnouncementPointNotification;
import com.ssn.simulation.entities.rober.communication.telegramtypes.RoBerTelegram;
import com.ssn.simulation.items.Pallet;

public class APNO implements TelegramHandler {
    public static final String TAG_STACKSIZE = "roberStacksize";

    protected RoBerController controller;

    public APNO(RoBerController controller) {
        this.controller = controller;
    }

    @Override
    public void handleTelegram(RoBerTelegram telegram) throws RoBerException {
        var apno = (APNOAnnouncementPointNotification) telegram;
        var conv = this.controller.getConveyorById(apno.getSource());
        if (!(conv instanceof RoBerConveyor)) {
            throw new RoBerException("conveyor " + apno.getSource() + " is not a ro-ber conveyor");
        }
        var source = (RoBerConveyor) conv;
        var item = source.getFirstItem();
        var stacksize = source.getAnnouncementCreationStacksize();
        if (item != null) {
            if (item.isMoving()) {
                throw new RoBerException("conveyor " + source.getId() + " is occupied by moving item " + item.getId());
            }
            item.setId(apno.getHuident());
            item.setIntegerTag(TAG_STACKSIZE, stacksize);
            source.moveItem();
            return;
        }
        if (source.isCreateOnAnnouncementTelegram()) {
            this.createPallet(source, apno.getHuident(), stacksize);
            return;
        }

        throw new RoBerException("no item on conveyor " + source.getId());
    }

    protected void createPallet(RoBerConveyor conveyor, String huident, int stacksize) {
        final Pallet pallet = new Pallet(this.controller.getCore());
        pallet.setId(huident);
        pallet.setSizex(conveyor.getPalletSizex());
        pallet.setSizey(conveyor.getPalletSizey());
        pallet.setSizez(conveyor.getPalletSizez());
        pallet.setWidth(conveyor.getPalletWidth());
        pallet.setLength(conveyor.getPalletLength());
        pallet.setHeight(conveyor.getPalletHeight());
        pallet.setWeight(conveyor.getPalletWeight());
        pallet.setIntegerTag(TAG_STACKSIZE, stacksize > 0 ? stacksize : 1);
        this.controller.getCore().addExternalEvent(() -> {
            if (conveyor.readyForExternalInput(pallet)) {
                conveyor.setCreateNotifictaion(false);
                conveyor.onInput(null, pallet);
                conveyor.moveItem();
            } else {
                conveyor.getCore().logError(conveyor,
                        "unable to create pallet, entity not ready for input");
            }
        });
    }
}
