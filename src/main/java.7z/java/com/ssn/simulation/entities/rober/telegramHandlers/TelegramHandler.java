package com.ssn.simulation.entities.rober.telegramHandlers;

import com.ssn.simulation.entities.rober.RoBerException;
import com.ssn.simulation.entities.rober.communication.telegramtypes.RoBerTelegram;

public interface TelegramHandler {
    public abstract void handleTelegram(RoBerTelegram telegram) throws RoBerException;
}
