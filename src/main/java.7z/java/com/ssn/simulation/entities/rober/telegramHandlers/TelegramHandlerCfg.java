package com.ssn.simulation.entities.rober.telegramHandlers;

import com.ssn.simulation.entities.rober.communication.telegramtypes.RoBerTelegram;

public class TelegramHandlerCfg {
    protected TelegramHandler handler;
    protected Class<? extends RoBerTelegram> telegramClass;

    public TelegramHandlerCfg(TelegramHandler handler, Class<? extends RoBerTelegram> telegramClass) {
        this.handler = handler;
        this.telegramClass = telegramClass;
    }

    public TelegramHandler getHandler() {
        return handler;
    }

    public Class<? extends RoBerTelegram> getTelegramClass() {
        return telegramClass;
    }
}
