package com.ssn.simulation.plugin.zFTS1;

import com.ssn.simulation.entities.BinWeaselRoutingStrategy;

public class zRoutingStrategy extends BinWeaselRoutingStrategy {

}
