package com.ssn.simulation.plugin.zFTS1;

import com.ssn.simulation.telegrams.Telegram;

import java.io.Serializable;

public class zTG1_POSO extends zTG1 {

    // Positionierungsauftrag

    protected int HU_Höhe;
    protected String MFS_Error;
    protected String HU_Nummer;
    protected String Reserve;
    protected String Quelle;

    public zTG1_POSO(String telegrammstring) {
        super(telegrammstring);
        this.Quelle = telegrammstring.substring(48, 66);
        this.HU_Nummer = telegrammstring.substring(66, 86);
        this.HU_Höhe = Integer.parseInt(telegrammstring.substring(86, 90));
        this.MFS_Error = telegrammstring.substring(90, 94);
        this.Reserve = telegrammstring.substring(94, 138);

    }
}
