package com.ssn.simulation.entities.rober;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.ssn.simulation.properties.StringProperty;

@JsonTypeInfo(use = JsonTypeInfo.Id.NONE)
public class ConveyorIdMapping implements Serializable, Cloneable {
    private static final long serialVersionUID = 1L;

    @StringProperty(allowEmpty = false, tooltip = "rober name of conveyor (value in telegrams)")
    private String roberId;

    @StringProperty(allowEmpty = false, tooltip = "antSim ID of conveyor")
    private String conveyorId;

    public String getRoberId() {
        return roberId;
    }

    public String getConveyorId() {
        return conveyorId;
    }
}