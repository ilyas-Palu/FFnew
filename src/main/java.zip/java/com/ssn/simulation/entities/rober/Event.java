package com.ssn.simulation.entities.rober;

public interface Event {
    void onEvent();
}
