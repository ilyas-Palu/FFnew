package com.ssn.simulation.entities.rober;

import java.awt.Graphics;

import javax.swing.JFrame;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.ssn.simulation.core.Entity;
import com.ssn.simulation.core.Item;
import com.ssn.simulation.editor.EntityRuntimeDialog;
import com.ssn.simulation.editor.Viewport;
import com.ssn.simulation.entities.PalletConveyor;
import com.ssn.simulation.entities.rober.communication.telegramtypes.INFO;
import com.ssn.simulation.entities.rober.communication.telegramtypes.LLFTCommunicationPointLeft;
import com.ssn.simulation.properties.BooleanProperty;
import com.ssn.simulation.properties.IntegerProperty;
import com.ssn.simulation.properties.LongProperty;
import com.ssn.simulation.properties.StringProperty;

public class RoBerConveyor extends PalletConveyor {// AbstractConveyor {
    @StringProperty(category = "ro-ber", allowEmpty = false)
    protected String roberResource;

    @BooleanProperty(category = "ro-ber")
    protected boolean sendInfoTelegram;

    @LongProperty(category = "ro-ber")
    protected long processingTime = 2000;

    @BooleanProperty(category = "ro-ber")
    protected boolean moveOn = true;

    @BooleanProperty(category = "ro-ber")
    protected boolean createOnAnnouncementTelegram;

    @IntegerProperty(category = "ro-ber", tooltip = "stacksize used for pallets created with an announcement telegram", min = 1)
    protected int announcementCreationStacksize = 5;

    @BooleanProperty(category = "ro-ber")
    protected boolean cpLeftTelegram;

    @BooleanProperty(category = "Visualisation")
    protected boolean showConveyorId;

    @JsonIgnore
    protected RoBerController controller;

    @JsonIgnore
    protected String roberId;

    @JsonIgnore
    protected boolean blockOutput;

    @Override
    public void onReset() {
        super.onReset();

        if (!this.moveOn) {
            this.blockOutput = true;
        }
    }

    public void moveItem() {
        if (!this.hasItem()) {
            return;
        }
        this.blockOutput = false;
        this.triggerEntity();
    }

    public void setController(RoBerController controller) {
        this.controller = controller;
    }

    @Override
    public String getCategory() {
        return "ro-ber";
    }

    @Override
    public EntityRuntimeDialog getRuntimeDialog(JFrame parent) {
        return new RoberConveyorRuntimeDialog(parent);
    }

    @Override
    public void onInput(Entity input, Item item) {
        super.onInput(input, item);

        if (this.sendInfoTelegram) {
            this.sendInfoTelegram();
        }
    }

    protected void sendInfoTelegram() {
        if (this.controller == null || !this.hasItem()) {
            return;
        }

        var info = this.controller.createTelegram(INFO.class);
        info.setHuident(this.getFirstItem().getId());
        info.setSource(this.getId());
        this.controller.sendTelegram(info);
    }

    public long getProcessingTime() {
        return processingTime;
    }

    @Override
    public boolean readyForOutput(Entity output, Item item) {
        return super.readyForOutput(output, item) && !this.blockOutput;
    }

    public boolean isMoveOn() {
        return moveOn;
    }

    public boolean isCreateOnAnnouncementTelegram() {
        return createOnAnnouncementTelegram;
    }

    @Override
    public void onStartOutput(Entity output, Item item) {
        super.onStartOutput(output, item);
        
        if (!this.moveOn) {
            this.blockOutput = true;
        }
    }

    @Override
    public void onOutput(Entity output, Item item) {
        super.onOutput(output, item);
        
        if (this.cpLeftTelegram) {
            var telegram = this.controller.createTelegram(LLFTCommunicationPointLeft.class);
            telegram.setSource(this.getId());
            telegram.setHuident(item.getId());
            telegram.setCompleted(item.getBooleanTag("roberCompleted"));
            this.controller.sendTelegram(telegram);
        }
    }

    public String getRoberResource() {
        return roberResource;
    }

    @Override
    public void onDraw(Graphics g, Viewport viewport) {
        this.drawPolygon(g, viewport);
        if (this.showConveyorId && viewport.showDetails(this.core)) {
            g.drawString(getId(), xpointsi[0] + 4, ypointsi[0] + 14); 
        }
    }

    public String getRoberId() {
        return roberId != null ? roberId : this.id;
    }

    public void setRoberId(String roberId) {
        this.roberId = roberId;
    }

    public int getAnnouncementCreationStacksize() {
        return announcementCreationStacksize;
    }
}
