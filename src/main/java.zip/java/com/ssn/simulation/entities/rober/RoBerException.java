package com.ssn.simulation.entities.rober;

public class RoBerException extends Exception {
    public RoBerException(String msg) {
        super(msg);
    }
}
