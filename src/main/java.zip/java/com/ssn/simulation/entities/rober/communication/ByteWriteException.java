package com.ssn.simulation.entities.rober.communication;

public class ByteWriteException extends Exception {
    public ByteWriteException(String errorMessage) {
        super(errorMessage);
    }
}