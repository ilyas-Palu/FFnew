package com.ssn.simulation.entities.rober.communication;

public enum TelegramFieldType {
    CHAR,
    NUMC,
    BOOLEAN
}