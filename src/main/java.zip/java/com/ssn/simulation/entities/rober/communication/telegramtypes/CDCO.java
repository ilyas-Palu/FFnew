package com.ssn.simulation.entities.rober.communication.telegramtypes;

import com.ssn.simulation.entities.rober.communication.ByteHandler;
import com.ssn.simulation.entities.rober.communication.TelegramField;
import com.ssn.simulation.entities.rober.communication.TelegramFieldType;

public class CDCO extends RoBerTelegram implements MfsError {
    public static final String TELETYPE = "CDCO";

    @TelegramField(offset = 48, length = 18, type = TelegramFieldType.CHAR)
    protected String source;

    @TelegramField(offset = 66, length = 18, type = TelegramFieldType.CHAR)
    protected String destination;

    @TelegramField(offset = 84, length = 20, type = TelegramFieldType.CHAR)
    protected String huident1;

    @TelegramField(offset = 104, length = 20, type = TelegramFieldType.CHAR)
    protected String huident2;

    @TelegramField(offset = 124, length = 12, type = TelegramFieldType.CHAR)
    protected String hutyp;

    @TelegramField(offset = 136, length = 1, type = TelegramFieldType.BOOLEAN)
    protected boolean consolidate;

    @TelegramField(offset = 137, length = 4, type = TelegramFieldType.CHAR)
    protected String mfserror;

    public CDCO(ByteHandler byteHandler) {
        super(byteHandler);
    }

    @Override
    public String getTelegramType() {
        return TELETYPE;
    }

    public static String getTeletype() {
        return TELETYPE;
    }

    public String getSource() {
        return source;
    }

    public String getDestination() {
        return destination;
    }

    public String getHuident1() {
        return huident1;
    }

    public String getHuident2() {
        return huident2;
    }

    public String getHutyp() {
        return hutyp;
    }

    public boolean isConsolidate() {
        return consolidate;
    }

    @Override
    public String getMfserror() {
        return mfserror;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }

    public void setHuident1(String huident1) {
        this.huident1 = huident1;
    }

    public void setHuident2(String huident2) {
        this.huident2 = huident2;
    }

    public void setHutyp(String hutyp) {
        this.hutyp = hutyp;
    }

    public void setConsolidate(boolean consolidate) {
        this.consolidate = consolidate;
    }

    @Override
    public void setMfserror(String mfserror) {
        this.mfserror = mfserror;
    }
}
