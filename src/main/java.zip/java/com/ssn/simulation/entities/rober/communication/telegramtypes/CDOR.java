package com.ssn.simulation.entities.rober.communication.telegramtypes;

import com.ssn.simulation.entities.rober.communication.ByteHandler;
import com.ssn.simulation.entities.rober.communication.TelegramField;
import com.ssn.simulation.entities.rober.communication.TelegramFieldType;

public class CDOR extends RoBerTelegram {
    public static final String TELETYPE = "CDOR";

    @TelegramField(offset = 48, length = 18, type = TelegramFieldType.CHAR)
    protected String source;

    @TelegramField(offset = 66, length = 18, type = TelegramFieldType.CHAR)
    protected String destination;

    @TelegramField(offset = 84, length = 20, type = TelegramFieldType.CHAR)
    protected String huident1;

    @TelegramField(offset = 104, length = 20, type = TelegramFieldType.CHAR)
    protected String huident2;

    @TelegramField(offset = 124, length = 12, type = TelegramFieldType.CHAR)
    protected String hutyp;

    @TelegramField(offset = 136, length = 1, type = TelegramFieldType.BOOLEAN)
    protected boolean consolidate;

    @TelegramField(offset = 137, length = 4, type = TelegramFieldType.CHAR)
    protected String mfserror;

    public CDOR(ByteHandler byteHandler) {
        super(byteHandler);
    }

    @Override
    public String getTelegramType() {
        return TELETYPE;
    }

    public static String getTeletype() {
        return TELETYPE;
    }

    public String getSource() {
        return source;
    }

    public String getDestination() {
        return destination;
    }

    public String getHuident1() {
        return huident1;
    }

    public String getHuident2() {
        return huident2;
    }

    public String getHutyp() {
        return hutyp;
    }

    public boolean getConsolidate() {
        return consolidate;
    }

    public String getMfserror() {
        return mfserror;
    }
}
