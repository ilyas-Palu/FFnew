package com.ssn.simulation.entities.rober.communication.telegramtypes;

import com.ssn.simulation.entities.rober.communication.ByteHandler;
import com.ssn.simulation.entities.rober.communication.TelegramField;
import com.ssn.simulation.entities.rober.communication.TelegramFieldType;

public class COCOConsolidationOrderConfirmation extends RoBerTelegram implements MfsError {
    public static final String TELETYPE = "COCO";

    @TelegramField(offset = 48, length = 4, type = TelegramFieldType.CHAR)
    protected String mfserror;

    public COCOConsolidationOrderConfirmation(ByteHandler byteHandler) {
        super(byteHandler);
    }

    @Override
    public String getTelegramType() {
        return TELETYPE;
    }

    @Override
    public String getMfserror() {
        return mfserror;
    }

    @Override
    public void setMfserror(String mfserror) {
        this.mfserror = mfserror;
    }    
}
