package com.ssn.simulation.entities.rober.communication.telegramtypes;

import com.ssn.simulation.entities.rober.communication.ByteHandler;

public class Life extends RoBerTelegram {
    public static final String TELETYPE = "LIFE";

    @Override
    public String getTelegramType() {
        return TELETYPE;
    }

    public Life(ByteHandler byteHandler) {
        super(byteHandler);
    }
}
