package com.ssn.simulation.entities.rober.communication.telegramtypes;

public interface MfsError {
    public String getMfserror();
    public void setMfserror(String mfserror);
}
