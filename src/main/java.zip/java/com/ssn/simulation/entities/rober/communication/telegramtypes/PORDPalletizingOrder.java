package com.ssn.simulation.entities.rober.communication.telegramtypes;

import com.ssn.simulation.entities.rober.communication.ByteHandler;
import com.ssn.simulation.entities.rober.communication.TelegramField;
import com.ssn.simulation.entities.rober.communication.TelegramFieldType;

public class PORDPalletizingOrder extends RoBerTelegram {
    public static final String TELETYPE = "PORD";

    @TelegramField(offset = 48, length = 18, type = TelegramFieldType.CHAR)
    protected String source;

    @TelegramField(offset = 66, length = 18, type = TelegramFieldType.CHAR)
    protected String destination;

    @TelegramField(offset = 84, length = 20, type = TelegramFieldType.CHAR)
    protected String huident;

    @TelegramField(offset = 104, length = 12, type = TelegramFieldType.CHAR)
    protected String hutyp;

    @TelegramField(offset = 116, length = 1, type = TelegramFieldType.BOOLEAN)
    protected boolean alternating;

    @TelegramField(offset = 117, length = 1, type = TelegramFieldType.BOOLEAN)
    protected boolean palletCover;

    @TelegramField(offset = 118, length = 4, type = TelegramFieldType.CHAR)
    protected String mfserror;

    public PORDPalletizingOrder(ByteHandler byteHandler) {
        super(byteHandler);
    }

    @Override
    public String getTelegramType() {
        return TELETYPE;
    }

    public String getSource() {
        return source;
    }

    public String getDestination() {
        return destination;
    }

    public String getHuident() {
        return huident;
    }

    public String getHutyp() {
        return hutyp;
    }

    public boolean getAlternating() {
        return alternating;
    }

    public boolean getPalletCover() {
        return palletCover;
    }

    public String getMfserror() {
        return mfserror;
    }
}
