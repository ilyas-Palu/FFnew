package com.ssn.simulation.entities.rober.communication.telegramtypes;

import com.ssn.simulation.entities.rober.communication.ByteHandler;
import com.ssn.simulation.entities.rober.communication.TelegramField;
import com.ssn.simulation.entities.rober.communication.TelegramFieldType;

public class PUCO extends RoBerTelegram {
    public static final String TELETYPE = "PUCO";

    @TelegramField(offset = 48, length = 18, type = TelegramFieldType.CHAR)
    protected String source;

    @TelegramField(offset = 66, length = 18, type = TelegramFieldType.CHAR)
    protected String destination;

    @TelegramField(offset = 84, length = 20, type = TelegramFieldType.CHAR)
    protected String huident1;

    @TelegramField(offset = 104, length = 20, type = TelegramFieldType.CHAR)
    protected String huident2;

    @TelegramField(offset = 124, length = 4, type = TelegramFieldType.CHAR)
    protected String mfserror;

    public PUCO(ByteHandler byteHandler) {
        super(byteHandler);
    }
    
    @Override
    public String getTelegramType() {
        return TELETYPE;
    }

    public String getSource() {
        return source;
    }

    public String getDestination() {
        return destination;
    }

    public String getHuident1() {
        return huident1;
    }

    public String getHuident2() {
        return huident2;
    }

    public String getMfserror() {
        return mfserror;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }

    public void setHuident1(String huident1) {
        this.huident1 = huident1;
    }

    public void setHuident2(String huident2) {
        this.huident2 = huident2;
    }

    public void setMfserror(String mfserror) {
        this.mfserror = mfserror;
    }
    
}
