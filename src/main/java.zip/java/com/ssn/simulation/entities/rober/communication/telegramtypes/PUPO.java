package com.ssn.simulation.entities.rober.communication.telegramtypes;

import com.ssn.simulation.entities.rober.communication.ByteHandler;
import com.ssn.simulation.entities.rober.communication.TelegramField;
import com.ssn.simulation.entities.rober.communication.TelegramFieldType;

public class PUPO extends RoBerTelegram {
    public static final String TELETYPE = "PUPO";

    @TelegramField(offset = 48, length = 18, type = TelegramFieldType.CHAR)
    protected String source;

    @TelegramField(offset = 66, length = 18, type = TelegramFieldType.CHAR)
    protected String destination;

    @TelegramField(offset = 84, length = 20, type = TelegramFieldType.CHAR)
    protected String huident1;

    @TelegramField(offset = 104, length = 12, type = TelegramFieldType.CHAR)
    protected String hutyp1;

    @TelegramField(offset = 116, length = 20, type = TelegramFieldType.CHAR)
    protected String huident2;

    @TelegramField(offset = 136, length = 12, type = TelegramFieldType.CHAR)
    protected String hutyp2;

    @TelegramField(offset = 148, length = 1, type = TelegramFieldType.BOOLEAN)
    protected boolean cover;

    @TelegramField(offset = 149, length = 2, type = TelegramFieldType.NUMC)
    protected int griptype;

    @TelegramField(offset = 151, length = 1, type = TelegramFieldType.CHAR)
    protected String position;

    @TelegramField(offset = 152, length = 1, type = TelegramFieldType.NUMC)
    protected int rotation;

    @TelegramField(offset = 153, length = 1, type = TelegramFieldType.BOOLEAN)
    protected boolean last;

    @TelegramField(offset = 154, length = 4, type = TelegramFieldType.CHAR)
    protected String mfserror;
    
    public PUPO(ByteHandler byteHandler) {
        super(byteHandler);
    }

    @Override
    public String getTelegramType() {
        return TELETYPE;
    }

    public String getSource() {
        return source;
    }

    public String getDestination() {
        return destination;
    }

    public String getHuident1() {
        return huident1;
    }

    public String getHutyp1() {
        return hutyp1;
    }

    public String getHuident2() {
        return huident2;
    }

    public String getHutyp2() {
        return hutyp2;
    }

    public boolean hasCover() {
        return cover;
    }

    public int getGriptype() {
        return griptype;
    }

    public String getPosition() {
        return position;
    }

    public int getRotation() {
        return rotation;
    }

    public boolean isLast() {
        return last;
    }

    public String getMfserror() {
        return mfserror;
    }    
}
