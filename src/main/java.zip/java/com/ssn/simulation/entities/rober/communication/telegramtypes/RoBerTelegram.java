package com.ssn.simulation.entities.rober.communication.telegramtypes;

import java.nio.charset.StandardCharsets;

import com.ssn.simulation.entities.rober.communication.ByteHandler;
import com.ssn.simulation.entities.rober.communication.TelegramField;
import com.ssn.simulation.entities.rober.communication.TelegramHeaderFields;

public abstract class RoBerTelegram implements com.ssn.simulation.telegrams.Telegram {
    protected ByteHandler byteHandler;

    protected TelegramHeaderFields header;

    public RoBerTelegram(ByteHandler byteHandler) {
        this.header = new TelegramHeaderFields();
        this.byteHandler = byteHandler;
    }

    public abstract String getTelegramType();

    public TelegramHeaderFields getHeader() {
        return this.header;
    }

    public void setHeader(TelegramHeaderFields header) {
        this.header = header;
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append(this.getTelegramType());
        builder.append(" [");
        for (var attr : this.header.getClass().getDeclaredFields()) {
            var field = attr.getAnnotation(TelegramField.class);
            if (field == null) {
                continue;
            }
            attr.setAccessible(true);
            builder.append(attr.getName());
            builder.append('=');
            try {
                var val = attr.get(this.header);
                builder.append(val == null ? "null" : val.toString());
            } catch (IllegalAccessException e) {
                builder.append("<error reading value from object>");
            }
            builder.append(", ");
        }
        for (var attr : this.getClass().getDeclaredFields()) {
            var field = attr.getAnnotation(TelegramField.class);
            if (field == null) {
                continue;
            }
            builder.append(attr.getName());
            builder.append('=');
            try {
                var val = attr.get(this);
                builder.append(val == null ? "null" : val.toString());
            } catch (IllegalAccessException e) {
                builder.append("<error reading value from object>");
            }
            builder.append(", ");
        }
        try {
            builder.append("raw=");
            var bytes = this.byteHandler.createTelegram();
            this.byteHandler.write(this.getHeader(), bytes);
            this.byteHandler.write(this, bytes);
            builder.append(new String(bytes, StandardCharsets.US_ASCII));
        } catch (Exception e) {
            builder.append("<error>");
        }

        builder.append(']');
        return builder.toString();
    }

    public ByteHandler getByteHandler() {
        return byteHandler;
    }
}
