package com.ssn.simulation.entities.rober.telegramHandlers;

import com.ssn.simulation.entities.rober.RoBerException;
import com.ssn.simulation.entities.rober.RoBerController;
import com.ssn.simulation.entities.rober.communication.telegramtypes.CANC;
import com.ssn.simulation.entities.rober.communication.telegramtypes.CORDConsolidationOrder;
import com.ssn.simulation.entities.rober.communication.telegramtypes.DORDDepalletizingOrder;
import com.ssn.simulation.entities.rober.communication.telegramtypes.MfsError;
import com.ssn.simulation.entities.rober.communication.telegramtypes.PORDPalletizingOrder;
import com.ssn.simulation.entities.rober.communication.telegramtypes.RoBerTelegram;
import com.ssn.simulation.entities.rober.orders.ConsolidationOrder;
import com.ssn.simulation.entities.rober.orders.DepalletizingOrder;
import com.ssn.simulation.entities.rober.orders.PalletizingOrder;
import com.ssn.simulation.entities.rober.orders.RoBerOrder;

public class Order {
    protected RoBerController controller;

    public Order(RoBerController controller) {
        this.controller = controller;
    }

    public void handleStartOrderTelegram(RoBerTelegram telegram) {
        if (this.controller.getOrder() != null) {
            this.controller.logError("open order; change of order mode not possible");
            this.controller.sendCancelByTelegram(telegram, "MFMC");
            return;
        }
        RoBerOrder order = null;
        if (telegram instanceof PORDPalletizingOrder) {
            order = new PalletizingOrder(this.controller, (PORDPalletizingOrder)telegram);
        } else if (telegram instanceof DORDDepalletizingOrder) {
            order = new DepalletizingOrder(this.controller, (DORDDepalletizingOrder)telegram);
        } else if (telegram instanceof CORDConsolidationOrder) {
            order = new ConsolidationOrder(this.controller, (CORDConsolidationOrder)telegram);
        } else {
            this.controller.logError("invalid telegram type " + telegram.getTelegramType() + " received");
            return;
        }
        this.controller.setOrder(order);
        var orderStartConf = order.buildOrderStartConfirmation();
        try {
            order.startOrder();
        } catch (RoBerException e) {
            this.controller.setOrder(null);
            this.controller.logError(e.getMessage());
            if (orderStartConf instanceof MfsError) {
                ((MfsError)orderStartConf).setMfserror("MFMC");
            }
        }
        this.controller.sendTelegram(orderStartConf);
    }

    public void handleOrderTelegram(RoBerTelegram telegram) {
        var order = this.controller.getOrder();
        if (order == null) {
            this.controller.logError("no active order; telegram cannot be processed");
            this.controller.sendOSTA(null, null, "MWOT");
            return;
        }

        if (order.isProcessing()) {
            this.controller.logError("cannot process telegram, ro-ber is working");
            this.controller.sendOSTA(null, null, "MWOT");
            return;
        }

        try {
            order.handleTelegram(telegram);
        } catch (RoBerException e) {
            this.controller.logError(e.getMessage());
        }
    }

    public void handleCancelTelegram(CANC telegram) {
        var order = this.controller.getOrder();
        if (order == null) {
            this.controller.logError("no active order; cancel not possible");
            return;
        }
        try {
            order.cancelOrder(telegram);
        } catch (RoBerException e) {
            this.controller.logError("error during cancellation of order: " + e.getMessage());
        }
        this.controller.setOrder(null);
        
        var canc = this.controller.createTelegram(CANC.class);
        canc.setMfserror("MROC");
        this.controller.sendTelegram(canc);
    }
}
