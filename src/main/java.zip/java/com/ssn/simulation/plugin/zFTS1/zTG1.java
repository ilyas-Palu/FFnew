package com.ssn.simulation.plugin.zFTS1;

import com.ssn.simulation.telegrams.Telegram;
import com.ssn.simulation.telegrams.weasel.WeaselTelegram;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.Serializable;
import java.io.UnsupportedEncodingException;
import java.nio.ByteBuffer;

public class zTG1 implements Telegram, Serializable {

    // implementiert den Telegramm Header für alle FTS Telegrammtypen

    public static final Object TELEGRAM_DELIMITER_START = "E";
    public static final Object TELEGRAM_DELIMITER_START_ALL = "EWMMFS";
    public static final Object TELEGRAM_DELIMITER_END_1 = "#";
    public static final Object TELEGRAM_DELIMITER_END_2 = "##";
    public static final String TELEGRAM_DELIMITER_HEADER1 = "MFSEWM..";
    public static final String TELEGRAM_DELIMITER_HEADER2 = "TOMPROD.";
    public static final String TELEGRAM_DELIMITER_ENDING = "##";
    protected String telegramtyp;
    protected String sender;
    protected String receiver;
    protected String CP;
    protected String Handshake;
    protected int sequencenumber;
    protected String Commerror;
    protected String telegramsubtype;

    protected String stringtelegram;

    protected zTG1 header;

    // gemeinsame spezfische Nutzdatenfelder

    protected String Endekennzeichen;

    // Ableitungen Weaseltelegramm

    protected byte telegramType;
    protected int tsn;
    protected String fleetId;
    protected String FTFId;
    protected boolean assigned;
    protected byte[] confarray;
    public Boolean confirmed;

    protected zTG1(String telegrammstring) {
        telegramtyp = "FTS_TG";
        confirmed = false;

        // IF Prüfung, dass String 140 Zeichen hat / Byt

        // evtl Prüfung Sequenznummer inlusive Singleton Umsetzung

        stringtelegram = telegrammstring;

        sender = telegrammstring.substring(0, 8);
        receiver = telegrammstring.substring(8, 16);
        CP = telegrammstring.substring(16, 34);
        Handshake = telegrammstring.substring(34, 36);
        sequencenumber = Integer.parseInt(telegrammstring.substring(36, 40));
        Commerror = telegrammstring.substring(40, 44);
        telegramsubtype = telegrammstring.substring(44, 48);

        // header.stringtelegram = telegrammstring;
        Endekennzeichen = telegrammstring.substring(138, 140);

    }

    protected zTG1() {
        telegramtyp = "FTS_TG";
        confirmed = false;
    }

    public static zTG1 interpret(String telegrammstring) {

        // IF Prüfung, dass String 140 Zeichen hat / Byt

        // evtl Prüfung Sequenznummer inlusive Singleton Umsetzung

        String Telegramsubtypecheck = telegrammstring.substring(44, 48);

        // header.stringtelegram = telegrammstring;

        switch (Telegramsubtypecheck) {
            case "WTSK":
                return new zTG1_WTSK(telegrammstring);

            case "WTCO":
                return new zTG1_WTCO(telegrammstring);

            case "POSO":
                return new zTG1_POSO(telegrammstring);

            case "INFO":
                return new zTG1_INFO(telegrammstring);

            case "LIFE":
                return new zTG1_LIFE(telegrammstring);
        }

        return null;

    }

    /*
     * public byte[] getByteOutputStream() throws Exception {
     * ByteArrayOutputStream stream = new ByteArrayOutputStream();
     * ByteArrayOutputStream result = new ByteArrayOutputStream();
     * write(stream, 1, telegramType);
     * writeAndfillUpWithZero(stream, 5, tsn);
     * writeAndfillUpWithBlanks(stream, 5, fleetId);
     * writeAndfillUpWithBlanks(stream, 5, FTPId);
     * fillBytes(stream);
     * write(result, 1, WeaselTelegram.TELEGRAM_DELIMITER_START);
     * checksum = getCrc16(stream.toByteArray());
     * writeAndfillUpWithZero(result, 5, checksum);
     * write(result, stream.toByteArray());
     * write(result, 1, WeaselTelegram.TELEGRAM_DELIMITER_END);
     * return result.toByteArray();
     * }
     */

    public static final void write(ByteArrayOutputStream stream, int bytes, Object value) throws IOException {
        stream.write(ByteBuffer.allocate(bytes).put(value.toString().getBytes()).array());
    }

    public static final int getCrc16(byte[] bytes) {
        short poly = (short) 0xa001;
        int[] table = new int[256];
        int unsignedPoly = poly & 0xffff;
        for (int i = 0; i < table.length; ++i) {
            int r = i;
            for (int j = 0; j < 8; ++j) {
                if ((r & 1) != 0) {
                    r = (r >>> 1) ^ unsignedPoly;
                } else {
                    r >>>= 1;
                }
            }
            table[i] = (short) r;
        }
        int value = 0;
        for (int i = 0; i < bytes.length; ++i) {
            byte b = bytes[i];
            value = (table[(value ^ b) & 0xff] ^ (value >>> 8)) & 0xffff;
        }
        return value;
    }

    public static final int checkCrc16(String telegramValue) { // Anpassen zum Beispiel auf Telegrammsubtyp notwendig
                                                               // cn1 Wenn hier Sequencenumber gecheckt wird hätte es
                                                               // Performance Vorteile -> Entscheidung dagegen
                                                               // wegen Erweiterbarkeit
        try {
            int checksum = Integer.valueOf(telegramValue.substring(1, 6).trim());
            if (checksum == 0) {
                return 0; // ignore
            } else {
                String telegram = telegramValue.substring(6, telegramValue.length() - 1);
                int expected = getCrc16(telegram.getBytes());
                if (checksum == expected) {
                    return 1; // ok
                } else {
                    return -1; // not ok
                }
            }
        } catch (Exception e) {
            return -2;
        }
    }

    public String getFTFId() {
        return FTFId;
    }

    public void setFTFId(String weaselId) {
        this.FTFId = weaselId;
    }

    public void setAssigned(boolean b) {
        this.assigned = b;
    }

    // Neue statische Methode Sender und Empfänger tauschen um Quittierungstelegramm
    // zu erhalten

    public void getConfirmation() {
        // Abklären ob Felder des Subtyps verloren gehen, und wann Erstellung und
        // Rückgabe Sinn machen -> Durch reine Stringverwendung gelöst

        try {
            byte[] byteArray = this.stringtelegram.getBytes("UTF-8");

            byte[] temp = new byte[8];

            System.arraycopy(byteArray, 0, temp, 0, 8);

            // Kopieren der Bytes von 9 bis 16 an die Positionen 0 bis 7 im ursprünglichen
            // Byte-Array
            System.arraycopy(byteArray, 8, byteArray, 0, 8);

            // Kopieren der Bytes aus dem temporären Byte-Array an die Positionen 8 bis 15
            // im ursprünglichen Byte-Array
            System.arraycopy(temp, 0, byteArray, 8, 8);

            this.confarray = byteArray;

        } catch (UnsupportedEncodingException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

    }

    // Methode zur Auffüllung mit Punkten bis zur gewünschten Länge
    protected static String fillWithDots(String value, int length) {
        StringBuilder sb = new StringBuilder(value);
        int diff = length - value.length();
        for (int i = 0; i < diff; i++) {
            sb.append(".");
        }
        return sb.toString();
    }

    public static zTG1 getHeader(zTG1 obj) {
        obj.sender = zTG1.TELEGRAM_DELIMITER_HEADER2;
        obj.receiver = zTG1.TELEGRAM_DELIMITER_HEADER1;
        obj.CP = null;
        obj.Handshake = "D.";
        obj.sequencenumber = 0;
        obj.Commerror = "";
        return obj;

    }

    // in Bytearray für Output

}
