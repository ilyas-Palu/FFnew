package com.ssn.simulation.plugin.zFTS1;

import com.ssn.simulation.telegrams.Telegram;

import java.io.Serializable;

public class zTG1_WTSK extends zTG1 {

    // Fahrauftrag

    protected String Ziel;
    protected String Paarbit;
    protected String MFS_Error;
    protected String HU_Nummer;
    protected String Reserve;
    protected String Quelle;
    protected int HU_Höhe;
    protected String Prioritätsbit;

    public zTG1_WTSK(String telegrammstring) {
        super(telegrammstring);
        this.Quelle = telegrammstring.substring(48, 66);
        this.Ziel = telegrammstring.substring(66, 84);
        this.HU_Nummer = telegrammstring.substring(84, 104);
        this.HU_Höhe = Integer.parseInt(telegrammstring.substring(104, 108));
        this.Paarbit = telegrammstring.substring(108);
        this.Prioritätsbit = telegrammstring.substring(109);
        this.MFS_Error = telegrammstring.substring(110, 114);
        this.Reserve = telegrammstring.substring(114, 138);

    }

}
